package com.akshay.dockerExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
